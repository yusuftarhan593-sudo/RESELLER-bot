# 🤖 Telegram Reseller Bot - Kurulum Rehberi

## 📁 Dosya Yapısı
```
bot/
├── main.py           # Ana dosya
├── config.py         # Ayarlar (token, admin ID)
├── database.py       # Veritabanı
├── keyboards.py      # Butonlar
├── requirements.txt  # Kütüphaneler
└── handlers/
    ├── __init__.py
    ├── user.py       # Kullanıcı komutları
    └── admin.py      # Admin paneli
```

---

## 🚀 Kurulum (VPS - Ubuntu/Debian)

### 1. Python Kur
```bash
sudo apt update
sudo apt install python3 python3-pip -y
```

### 2. Bot Dosyalarını Yükle
```bash
mkdir ~/bot && cd ~/bot
# Tüm dosyaları bu klasöre yükle
```

### 3. Kütüphaneleri Yükle
```bash
pip3 install -r requirements.txt
```

### 4. Config Ayarla
`config.py` dosyasını aç ve düzenle:
```python
BOT_TOKEN = "BURAYA_BOT_TOKEN_YAZ"   # @BotFather'dan al
ADMIN_IDS = [123456789]               # Kendi Telegram ID'n (@userinfobot'tan öğren)
```

### 5. Botu Başlat
```bash
python3 main.py
```

### 6. Arka Planda Çalıştır (Önemli!)
```bash
# screen ile:
screen -S bot
python3 main.py
# CTRL+A, D ile çık (bot çalışmaya devam eder)

# veya systemd service olarak:
sudo nano /etc/systemd/system/telegram-bot.service
```

**systemd service içeriği:**
```ini
[Unit]
Description=Telegram Reseller Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/bot
ExecStart=/usr/bin/python3 /root/bot/main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable telegram-bot
sudo systemctl start telegram-bot
sudo systemctl status telegram-bot
```

---

## 🎮 Kullanım

### Admin Komutları
- `/admin` → Admin panelini aç
- **Kategori Yönetimi** → Ekle/Sil/Düzenle
- **Ürün Yönetimi** → Ekle/Sil/Fiyat değiştir
- **Stok Ekle** → Ürüne key kodları yükle (her satıra bir key)
- **Kullanıcılar** → Bakiye yükle, indirim ver, ban/unban
- **İstatistikler** → Günlük/Haftalık/Aylık/Yıllık kazanç
- **Tüm Siparişler** → Son 100 sipariş

### Kullanıcı Komutları
- `/start` → Botu başlat
- **🛍️ Ürünler** → Kategoriler ve ürünler
- **💰 Bakiyem** → Bakiye görüntüle
- **📋 Siparişlerim** → Geçmiş siparişler
- **👤 Hesabım** → Profil bilgileri

---

## ⚙️ Özellikler
✅ Kategori yönetimi (ekle/sil/düzenle)
✅ Ürün yönetimi (ekle/sil/fiyat)
✅ Stok yönetimi (toplu key yükle)
✅ Bakiye sistemi
✅ Kişiye özel indirim
✅ Kullanıcı ban/unban
✅ Günlük/haftalık/aylık/yıllık istatistik
✅ Tüm sipariş geçmişi
✅ Ban koruması
