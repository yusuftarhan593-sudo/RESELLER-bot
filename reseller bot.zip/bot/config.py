BOT_TOKEN = "BURAYA_BOT_TOKEN_YAZ"
ADMIN_IDS = [123456789]  # Buraya kendi Telegram ID'ni yaz
DB_NAME = "bot.db"
