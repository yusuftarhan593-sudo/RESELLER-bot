import sqlite3
from config import DB_NAME
from datetime import datetime

def get_conn():
    return sqlite3.connect(DB_NAME)

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            full_name TEXT,
            balance REAL DEFAULT 0,
            custom_discount REAL DEFAULT 0,
            is_banned INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            emoji TEXT DEFAULT '📦',
            is_active INTEGER DEFAULT 1
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id INTEGER,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (category_id) REFERENCES categories(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS stock (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            key_code TEXT NOT NULL,
            is_sold INTEGER DEFAULT 0,
            sold_to INTEGER DEFAULT NULL,
            sold_at TEXT DEFAULT NULL,
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            product_id INTEGER,
            product_name TEXT,
            key_code TEXT,
            price REAL,
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS balance_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount REAL,
            note TEXT,
            added_by INTEGER,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)

    conn.commit()
    conn.close()

# ── KULLANICI ──────────────────────────────────────────────
def get_or_create_user(user_id, username, full_name):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = c.fetchone()
    if not user:
        c.execute("INSERT INTO users (user_id, username, full_name) VALUES (?,?,?)",
                  (user_id, username, full_name))
        conn.commit()
        c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
        user = c.fetchone()
    conn.close()
    return user

def get_user(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def get_all_users():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users ORDER BY created_at DESC")
    users = c.fetchall()
    conn.close()
    return users

def update_balance(user_id, amount):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()

def set_custom_discount(user_id, discount):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET custom_discount=? WHERE user_id=?", (discount, user_id))
    conn.commit()
    conn.close()

def ban_user(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned=1 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def unban_user(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned=0 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def log_balance(user_id, amount, note, added_by):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO balance_logs (user_id, amount, note, added_by) VALUES (?,?,?,?)",
              (user_id, amount, note, added_by))
    conn.commit()
    conn.close()

# ── KATEGORİ ──────────────────────────────────────────────
def add_category(name, emoji="📦"):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO categories (name, emoji) VALUES (?,?)", (name, emoji))
    conn.commit()
    conn.close()

def get_categories(active_only=True):
    conn = get_conn()
    c = conn.cursor()
    if active_only:
        c.execute("SELECT * FROM categories WHERE is_active=1")
    else:
        c.execute("SELECT * FROM categories")
    cats = c.fetchall()
    conn.close()
    return cats

def delete_category(cat_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE categories SET is_active=0 WHERE id=?", (cat_id,))
    conn.commit()
    conn.close()

def update_category(cat_id, name, emoji):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE categories SET name=?, emoji=? WHERE id=?", (name, emoji, cat_id))
    conn.commit()
    conn.close()

# ── ÜRÜN ──────────────────────────────────────────────────
def add_product(category_id, name, description, price):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO products (category_id, name, description, price) VALUES (?,?,?,?)",
              (category_id, name, description, price))
    conn.commit()
    conn.close()

def get_products(category_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE category_id=? AND is_active=1", (category_id,))
    products = c.fetchall()
    conn.close()
    return products

def get_product(product_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE id=?", (product_id,))
    p = c.fetchone()
    conn.close()
    return p

def delete_product(product_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE products SET is_active=0 WHERE id=?", (product_id,))
    conn.commit()
    conn.close()

def update_product_price(product_id, price):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE products SET price=? WHERE id=?", (price, product_id))
    conn.commit()
    conn.close()

def get_all_products_admin():
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        SELECT p.*, c.name as cat_name,
        (SELECT COUNT(*) FROM stock WHERE product_id=p.id AND is_sold=0) as stock_count
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.is_active=1
    """)
    products = c.fetchall()
    conn.close()
    return products

# ── STOK ──────────────────────────────────────────────────
def add_stock(product_id, keys: list):
    conn = get_conn()
    c = conn.cursor()
    for key in keys:
        key = key.strip()
        if key:
            c.execute("INSERT INTO stock (product_id, key_code) VALUES (?,?)", (product_id, key))
    conn.commit()
    conn.close()

def get_stock_count(product_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM stock WHERE product_id=? AND is_sold=0", (product_id,))
    count = c.fetchone()[0]
    conn.close()
    return count

def get_available_key(product_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM stock WHERE product_id=? AND is_sold=0 LIMIT 1", (product_id,))
    key = c.fetchone()
    conn.close()
    return key

def mark_key_sold(key_id, user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE stock SET is_sold=1, sold_to=?, sold_at=datetime('now') WHERE id=?",
              (user_id, key_id))
    conn.commit()
    conn.close()

# ── SİPARİŞ ──────────────────────────────────────────────
def create_order(user_id, product_id, product_name, key_code, price):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT INTO orders (user_id, product_id, product_name, key_code, price)
        VALUES (?,?,?,?,?)
    """, (user_id, product_id, product_name, key_code, price))
    conn.commit()
    conn.close()

def get_user_orders(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC", (user_id,))
    orders = c.fetchall()
    conn.close()
    return orders

def get_all_orders():
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        SELECT o.*, u.username, u.full_name
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.user_id
        ORDER BY o.created_at DESC
        LIMIT 100
    """)
    orders = c.fetchall()
    conn.close()
    return orders

# ── İSTATİSTİK ────────────────────────────────────────────
def get_earnings(period="daily"):
    conn = get_conn()
    c = conn.cursor()

    if period == "daily":
        date_filter = "date(created_at) = date('now')"
    elif period == "weekly":
        date_filter = "created_at >= datetime('now', '-7 days')"
    elif period == "monthly":
        date_filter = "created_at >= datetime('now', '-30 days')"
    elif period == "yearly":
        date_filter = "created_at >= datetime('now', '-365 days')"
    else:
        date_filter = "1=1"

    c.execute(f"SELECT COALESCE(SUM(price), 0), COUNT(*) FROM orders WHERE {date_filter}")
    result = c.fetchone()
    conn.close()
    return result  # (total_amount, order_count)

def get_stats():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM users")
    total_users = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM orders")
    total_orders = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(price), 0) FROM orders")
    total_revenue = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM stock WHERE is_sold=0")
    total_stock = c.fetchone()[0]
    conn.close()
    return total_users, total_orders, total_revenue, total_stock
