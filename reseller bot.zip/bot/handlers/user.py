from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart

import database as db
import keyboards as kb
from config import ADMIN_IDS

router = Router()

def is_admin(user_id):
    return user_id in ADMIN_IDS

# ── /start ────────────────────────────────────────────────
@router.message(CommandStart())
async def cmd_start(message: Message):
    user = db.get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.full_name
    )
    if user[5] == 1:  # banned
        await message.answer("⛔ Hesabınız yasaklanmıştır.")
        return

    await message.answer(
        f"👋 Merhaba, <b>{message.from_user.full_name}</b>!\n\n"
        "Aşağıdaki menüden işlemini seç:",
        parse_mode="HTML",
        reply_markup=kb.main_menu()
    )

# ── ÜRÜNLER ───────────────────────────────────────────────
@router.message(F.text == "🛍️ Ürünler")
async def show_categories(message: Message):
    categories = db.get_categories()
    if not categories:
        await message.answer("😔 Henüz kategori yok.")
        return
    await message.answer("📂 Kategori seç:", reply_markup=kb.categories_keyboard(categories))

@router.callback_query(F.data.startswith("cat_"))
async def show_products(callback: CallbackQuery):
    cat_id = int(callback.data.split("_")[1])
    products = db.get_products(cat_id)
    if not products:
        await callback.answer("😔 Bu kategoride ürün yok.", show_alert=True)
        return
    await callback.message.edit_text("📦 Ürün seç:", reply_markup=kb.products_keyboard(products, cat_id))

@router.callback_query(F.data.startswith("product_"))
async def show_product_detail(callback: CallbackQuery):
    product_id = int(callback.data.split("_")[1])
    product = db.get_product(product_id)
    if not product:
        await callback.answer("Ürün bulunamadı.", show_alert=True)
        return

    stock = db.get_stock_count(product_id)
    user = db.get_user(callback.from_user.id)

    # Kişiye özel indirim uygula
    discount = user[3+1] if user else 0  # custom_discount index 4
    price = product[4]
    if discount > 0:
        discounted = price * (1 - discount / 100)
        price_text = f"<s>{price}₺</s> → <b>{discounted:.2f}₺</b> (%{discount} indirim)"
    else:
        price_text = f"<b>{price}₺</b>"

    text = (
        f"🔑 <b>{product[2]}</b>\n\n"
        f"📝 {product[3] or 'Açıklama yok'}\n\n"
        f"💰 Fiyat: {price_text}\n"
        f"📦 Stok: {'✅ Mevcut' if stock > 0 else '❌ Tükendi'}"
    )
    await callback.message.edit_text(text, parse_mode="HTML",
                                      reply_markup=kb.product_detail_keyboard(product_id, product[1]))

@router.callback_query(F.data.startswith("buy_"))
async def buy_product(callback: CallbackQuery):
    product_id = int(callback.data.split("_")[1])
    product = db.get_product(product_id)
    user = db.get_user(callback.from_user.id)

    discount = user[4]
    price = product[4]
    if discount > 0:
        price = price * (1 - discount / 100)

    await callback.message.edit_text(
        f"🛒 Satın alma onayı\n\n"
        f"Ürün: <b>{product[2]}</b>\n"
        f"Fiyat: <b>{price:.2f}₺</b>\n"
        f"Bakiyeniz: <b>{user[3]:.2f}₺</b>\n\n"
        f"Onaylıyor musunuz?",
        parse_mode="HTML",
        reply_markup=kb.confirm_buy_keyboard(product_id)
    )

@router.callback_query(F.data.startswith("confirm_buy_"))
async def confirm_buy(callback: CallbackQuery):
    product_id = int(callback.data.split("_")[2])
    product = db.get_product(product_id)
    user = db.get_user(callback.from_user.id)

    if not product:
        await callback.answer("Ürün bulunamadı.", show_alert=True)
        return

    discount = user[4]
    price = product[4]
    if discount > 0:
        price = price * (1 - discount / 100)

    if user[3] < price:
        await callback.answer("❌ Yetersiz bakiye!", show_alert=True)
        return

    key = db.get_available_key(product_id)
    if not key:
        await callback.answer("❌ Stok tükendi!", show_alert=True)
        return

    # İşlem
    db.update_balance(callback.from_user.id, -price)
    db.mark_key_sold(key[0], callback.from_user.id)
    db.create_order(callback.from_user.id, product_id, product[2], key[1], price)

    await callback.message.edit_text(
        f"✅ Satın alma başarılı!\n\n"
        f"🔑 Ürün: <b>{product[2]}</b>\n"
        f"🗝️ Key: <code>{key[1]}</code>\n"
        f"💰 Ödenen: <b>{price:.2f}₺</b>",
        parse_mode="HTML"
    )

@router.callback_query(F.data == "back_categories")
async def back_to_categories(callback: CallbackQuery):
    categories = db.get_categories()
    await callback.message.edit_text("📂 Kategori seç:", reply_markup=kb.categories_keyboard(categories))

# ── BAKİYE ────────────────────────────────────────────────
@router.message(F.text == "💰 Bakiyem")
async def show_balance(message: Message):
    user = db.get_user(message.from_user.id)
    await message.answer(
        f"💰 <b>Bakiyeniz:</b> {user[3]:.2f}₺",
        parse_mode="HTML"
    )

# ── SİPARİŞLER ────────────────────────────────────────────
@router.message(F.text == "📋 Siparişlerim")
async def show_orders(message: Message):
    orders = db.get_user_orders(message.from_user.id)
    if not orders:
        await message.answer("📋 Henüz siparişiniz yok.")
        return

    text = "📋 <b>Son Siparişleriniz:</b>\n\n"
    for o in orders[:10]:
        text += f"• {o[3]} → <code>{o[4]}</code> | {o[5]:.2f}₺ | {o[6][:10]}\n"
    await message.answer(text, parse_mode="HTML")

# ── HESAP ─────────────────────────────────────────────────
@router.message(F.text == "👤 Hesabım")
async def show_account(message: Message):
    user = db.get_user(message.from_user.id)
    orders = db.get_user_orders(message.from_user.id)
    total_spent = sum(o[5] for o in orders)

    text = (
        f"👤 <b>Hesap Bilgileri</b>\n\n"
        f"🆔 ID: <code>{user[0]}</code>\n"
        f"👤 İsim: {user[2]}\n"
        f"💰 Bakiye: {user[3]:.2f}₺\n"
        f"🎁 İndirim: %{user[4]}\n"
        f"🛍️ Toplam Sipariş: {len(orders)}\n"
        f"💸 Toplam Harcama: {total_spent:.2f}₺\n"
        f"📅 Kayıt: {user[6][:10]}"
    )
    await message.answer(text, parse_mode="HTML")
